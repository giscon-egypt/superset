import { ControlPanelConfig } from '@superset-ui/chart-controls';
declare const config: ControlPanelConfig;
export default config;
//# sourceMappingURL=controlPanel.d.ts.map