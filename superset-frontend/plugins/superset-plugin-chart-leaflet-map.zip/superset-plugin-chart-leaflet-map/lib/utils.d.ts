export declare const createToolTip: (longitude: number, latitude: number, category: string) => HTMLDivElement;
//# sourceMappingURL=utils.d.ts.map